# Maps — Conceitos Transversais

[← Courses](../README.md) · [Classes](../classes/) · [Roadmap](../roadmap/)

Tracks respondem:

> **Em qual área este conteúdo é estudado?**

Maps respondem:

> **Onde o mesmo padrão reaparece em áreas diferentes?**

Os mapas devem permanecer sintéticos e apontar para masterclasses, notas e projetos. Não substituem cursos completos.

---

## 1. Computação

```text
lógica
↓
algoritmo
↓
representação
↓
execução
↓
hardware
```

Conecta principalmente A, B01/B12, C, F e I10.

---

## 2. Informação

```text
distinção
↓
codificação
↓
transmissão
↓
inferência
↓
representação
```

Aparece em:

- bits, armazenamento e memória;
- B10 — Teoria da Informação;
- E01 — redes;
- I02/I03 — biologia molecular e genética;
- D03 — código neural;
- C — machine learning;
- F — sistemas de IA.

---

## 3. Dinâmica

```text
estado
↓
regra de evolução
↓
trajetória
↓
estabilidade / instabilidade
↓
atratores / transições
```

Aparece em:

- B05/B09 — EDOs e sistemas dinâmicos;
- G01/G02/G03 — física;
- H04 — cinética química;
- I05/I07 — fisiologia e ecologia;
- D05/D06 — neurodinâmica;
- C05/C06 — treinamento e otimização.

---

## 4. Estrutura, Geometria e Topologia

```text
relações locais
↓
forma global
↓
invariantes
↓
espaços de estados / representações
```

Aparece em B06/B07/B08, G08, C02/C04 e D07/D08.

---

## 5. Memória e História

```text
estado presente
+
dependência do passado
↓
restrição sobre futuros possíveis
```

Aparece em:

- A07/A08 — memória computacional e virtual;
- E04 — persistência;
- D04/D10 — plasticidade e engramas;
- F03/F05 — memória em sistemas de IA;
- B09 — sistemas com estado e trajetória.

---

## 6. Energia, Trabalho e Recursos

```text
capacidade de transformação
↓
restrições
↓
dissipação / custo
```

Aparece em física, termodinâmica, química, metabolismo, hardware e computação de alto desempenho.

---

## 7. Escala e Emergência

```text
componentes locais
↓
interações
↓
padrões coletivos
↓
novas descrições efetivas
```

Aparece em multicore e distribuídos, mecânica estatística, química, biologia de sistemas, neurodinâmica e sistemas cognitivos.

---

## 8. Incerteza e Inferência

```text
observações incompletas
↓
modelo
↓
evidência
↓
atualização
↓
decisão
```

Aparece em probabilidade, física estatística, ciência experimental, ML, neurociência e avaliação de sistemas de IA.

---

## 9. Evolução, Aprendizado e Adaptação

```text
variação
+
seleção / feedback
+
memória
↓
mudança adaptativa
```

Aparece em evolução biológica, plasticidade neural, otimização, machine learning e sistemas adaptativos.

---

# Regra para novos mapas

Criar um novo mapa quando um conceito:

1. aparecer de forma importante em **três ou mais tracks**;
2. tiver significados relacionados, mas não idênticos;
3. for útil comparar o que permanece e o que muda entre escalas.

Evitar mapas baseados apenas em palavras superficialmente parecidas.
